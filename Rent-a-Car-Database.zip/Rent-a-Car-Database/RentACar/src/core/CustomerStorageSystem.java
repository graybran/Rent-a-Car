package core;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerStorageSystem {
    
    public void RegisterCustomer(int id, String firstName, String lastName, 
            int age, String phoneNumber, String emailAddress) {
        Customer newCustomer = new Customer();
        newCustomer.setCustID(id);
        newCustomer.setFirstName(firstName);
        newCustomer.setLastName(lastName);
        newCustomer.setAge(age);
        newCustomer.setPhoneNumber(phoneNumber);
        newCustomer.setEmailAddress(emailAddress);
        newCustomer.StoreCustomer();
    }
    
    public void UpdateCustomer(String firstName, String lastName, int newAge, 
            String newPhoneNumber, String newEmailAddress) {
        try {
            Scanner baseScan = new Scanner(new File("CustomerBase.txt"));
            while(baseScan.hasNextLine()) {
                String temp = baseScan.nextLine();
                System.out.println(temp);
            }
            baseScan.close();
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(CustomerStorageSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
