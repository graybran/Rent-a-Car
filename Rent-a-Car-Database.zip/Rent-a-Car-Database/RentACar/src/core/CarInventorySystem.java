package core;

public class CarInventorySystem
{
    /*
    public String year;
    public String make;
    public String model;
    public String carClass;
    public String ID;
    */

    public void AddCar(int ID, String brand, String model, String color, int year, 
            String carClass, boolean availability, double dailyPrice) {
        Vehicle newVehicle = new Vehicle();
        newVehicle.setID(ID);
        newVehicle.setMake(brand);
        newVehicle.setModel(model);
        newVehicle.setColor(color);
        newVehicle.setCarClass(carClass);
        newVehicle.setAvailability(availability);
        newVehicle.setDailyPrice(dailyPrice);
        newVehicle.StoreVehicle();
    }
    
    public void UpdateCar(String newBrand, String newModel, String newColor, 
            int newYear, String newCarClass, boolean newAvailability, 
            double newDailyPrice) {
        
    }
}
