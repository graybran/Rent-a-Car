package core;

public interface CustomerStorage {
    public void ReadCustomerEntry(String fileName);
}
