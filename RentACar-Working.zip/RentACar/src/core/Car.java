/*
    This is the class car. New car objects can be created with this
    The appropriate getters and setters are set
*/

package core;

public class Car
{
    public String year;
    public String make;
    public String model;
    public String carClass;
    public String ID;
}
