package core;

public interface InventorySystem {
    public void ReadVehicleEntry(String fileName);
}
